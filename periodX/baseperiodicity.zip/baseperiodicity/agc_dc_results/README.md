<ul>
<li> 
 
<b> first_run_22_09_2022.csv</b>: Preliminary results performed on AGN Data Challenge data. From the results it can be seen that the determination of the period errors can be strongly influenced by the peak width. Therefore, we need to apply some checking of the peak width and then we have to discard one error. For more clarification please see the example given in the <a href="https://github.com/LSST-sersag/periodicities/blob/main/agc_dc_results/AGN_DC_example.ipynb"> notebook </a>.
</li>
</ul>
